//
//  CocoaMQTT.h
//  CocoaMQTT
//
//  Created by CrazyWisdom on 15/12/11.
//  Copyright © 2015年 emqx.io. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for CocoaMQTT.
FOUNDATION_EXPORT double CocoaMQTTVersionNumber;

//! Project version string for CocoaMQTT.
FOUNDATION_EXPORT const unsigned char CocoaMQTTVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <CocoaMQTT/PublicHeader.h>
