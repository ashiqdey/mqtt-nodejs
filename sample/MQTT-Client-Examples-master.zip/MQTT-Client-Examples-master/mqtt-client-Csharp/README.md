# C# MQTT client examples
In this example we provide example code for C# to subscribe to topics and send messages.
For more documentation on the use of the paho.mqtt.m2mqtt client, see the [paho.mqtt.m2mqtt - documentation](https://www.eclipse.org/paho/index.php?page=clients/dotnet/index.php)


## Run
Execute the following command in the publish or subscribe directory
```bash
dotnet run
```