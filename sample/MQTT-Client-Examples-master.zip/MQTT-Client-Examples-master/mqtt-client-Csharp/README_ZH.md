# C# MQTT 客户端使用示例
在本示例中我们提供了 C# 订阅主题和发送信息的示例代码。
有关 paho.mqtt.m2mqtt 客户端更多使用文档，请参阅 [paho.mqtt.m2mqtt 官方文档](https://www.eclipse.org/paho/index.php?page=clients/dotnet/index.php)。


## 运行
在publish或者subscribe目录下执行以下命令
```bash
dotnet run
```
