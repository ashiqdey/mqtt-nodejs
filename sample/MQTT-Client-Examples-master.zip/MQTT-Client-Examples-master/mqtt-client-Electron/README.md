# MQTT-Client-Electron

```bash
# Install dependencies
npm install
# Run the app
npm start
```
