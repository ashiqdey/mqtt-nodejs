# MQTT-Client-WebSocket

You can directly open the `ws-mqtt.html` file in your browser and view the demo results in the console.

Or use key codes in the project for testing.
