package io.emqx.flutter_mqtt

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
