# Flutter MQTT example
A simple demo to show how to use mqtt with flutter.

## Prerequisites
- Android Studio
- [Flutter](https://flutter.dev/docs/get-started/install)

## Installation
```bash
flutter pub get
```

## Run
Import project to Android Studio and run


