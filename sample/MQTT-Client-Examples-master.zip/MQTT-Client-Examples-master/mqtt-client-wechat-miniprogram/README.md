# MQTT Client Wechat miniprogram

## 使用

克隆或下载该仓库，使用微信小程序导入 `mqtt-client-wechat-miniprogram` 文件夹即可使用

![mqtt](./mqtt.png)
