# Android MQTT Client Examples


## Prerequisites
* programing: Java
* MQTT Client: [Paho](https://github.com/eclipse/paho.mqtt.android)

 
## Run
Open the project in Android Studio, connect the virtual machine or device, and run