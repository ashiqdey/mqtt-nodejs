# Android 连接 MQTT 示例

* 语言：Java
* 客户端库：[Paho](https://github.com/eclipse/paho.mqtt.android)

## 运行
在 Android Studio 中打开项目，连接虚拟机或设备，运行